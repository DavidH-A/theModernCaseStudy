import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

class Graph:
    dataDf = pd.read_csv(r'modernCaseStudy\data\data.csv', index_col=0) #fetch data from .csv file
    cumulativeCases = False
    cumulativeDeaths = False
    startMonth = "Jan"
    endMonth = "Dec"
    newCases = False
    newDeaths = False
    totalCrime = False
    arsonDamage = False
    burglary = False
    drugOffences = False
    historicalFraud = False
    miscCrimes = False
    possessionOfWeapons = False
    publicOrder = False
    robbery = False
    sexualOffences = False
    theft = False
    vehicleOffences = False
    violence = False
    selection = np.array([])

    def __init__(self): #(default graph)
        self.cumulativeCases = True
        self.cumulativeDeaths = True
        self.totalCrime = True
    def GenerateGraph(self):
        self.selection = np.array([]) #clear the previous selections
        if (self.cumulativeCases): self.selection = np.append(self.selection, str(self.dataDf.columns[0])) #if user has selected this filter include in graph
        if (self.cumulativeDeaths): self.selection = np.append(self.selection, str(self.dataDf.columns[1]))
        if (self.newCases): self.selection = np.append(self.selection, str(self.dataDf.columns[2]))
        if (self.newDeaths): self.selection = np.append(self.selection, str(self.dataDf.columns[3])) 
        if (self.totalCrime): self.selection = np.append(self.selection, str(self.dataDf.columns[4]))
        if (self.arsonDamage): self.selection = np.append(self.selection, str(self.dataDf.columns[5]))
        if (self.burglary): self.selection = np.append(self.selection, str(self.dataDf.columns[6]))
        if (self.drugOffences): self.selection = np.append(self.selection, str(self.dataDf.columns[7]))
        if (self.historicalFraud): self.selection = np.append(self.selection, str(self.dataDf.columns[8]))
        if (self.miscCrimes): self.selection = np.append(self.selection, str(self.dataDf.columns[9]))
        if (self.possessionOfWeapons): self.selection = np.append(self.selection, str(self.dataDf.columns[10]))
        if (self.publicOrder): self.selection = np.append(self.selection, str(self.dataDf.columns[11]))
        if (self.robbery): self.selection = np.append(self.selection, str(self.dataDf.columns[12]))
        if (self.sexualOffences): self.selection = np.append(self.selection, str(self.dataDf.columns[13]))
        if (self.theft): self.selection = np.append(self.selection, str(self.dataDf.columns[14]))
        if (self.vehicleOffences): self.selection = np.append(self.selection, str(self.dataDf.columns[15]))
        if (self.violence): self.selection = np.append(self.selection, str(self.dataDf.columns[16]))   
        self.dataDf.loc[self.startMonth:self.endMonth, self.selection].plot() #creates graph  
        plt.savefig("modernCaseStudy/static/images/graphs/current_graph.png", dpi=1500) #save as png
        
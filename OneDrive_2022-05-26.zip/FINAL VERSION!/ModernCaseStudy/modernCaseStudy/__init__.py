import sys
import subprocess
#===AUTO-DOWNLOAD AND INSTALL DEPENDENCIES===
try:
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pipenv']) #installs pipenv
    subprocess.check_call([sys.executable, '-m','pip', 'install', '-r','requirements.txt']) #installs all needed modules
except:
    print("ERROR: auto-dependencies installation unsuccessful.\nPlease refer to READ_ME for manual Python module installation instructions")
            

from flask import Flask, flash
import modernCaseStudy.graphCode
app = Flask(__name__)   #__name__ is just the name of module (main.py)
app.config['SECRET_KEY']= '8495bf6cfe8eaa34cfc77116d13ecda9'
from modernCaseStudy import routes
#THIS SCRIPT MUST BE RUN FIRST IN ORDER TO START THE SYSTEM
from modernCaseStudy import app
import sys

if __name__=="__main__":
    app.run(debug=True)
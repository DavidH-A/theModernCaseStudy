#Note don't forget to mention that everything is in a package...
import sys
import subprocess
try:
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pipenv']) #installs pipenv
    subprocess.check_call([sys.executable, '-m','pip', 'install', '-r','requirements.txt']) #installs all needed modules
except:
    print("auto-installation unsuccessful. Please refer to READ_ME for manual installation instructions")
from flask import Flask, flash
import modernCaseStudy.graphCode
app = Flask(__name__)   #__name__ is just the name of module (main.py)
app.config['SECRET_KEY']= '8495bf6cfe8eaa34cfc77116d13ecda9'
from modernCaseStudy import routes
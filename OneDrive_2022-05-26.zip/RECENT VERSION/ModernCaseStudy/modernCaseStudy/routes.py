from flask import render_template, request, redirect, flash, make_response
from modernCaseStudy import app
import modernCaseStudy
import modernCaseStudy.graphCode
from modernCaseStudy.graphCode import Graph

graph = Graph()
graph.GenerateGraph()
@app.route('/', methods=['GET','POST'])
def home():
    if request.method == 'POST':
        return redirect('/dashboard')
    else:
        return render_template('landing.html',title='Home')
    

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
        return render_template('dashboard.html',title='Dashboard')

@app.route('/aboutUs')
def aboutUs():
    return render_template('aboutUs.html',title='About Us')

@app.route('/contactUs')
def contactUs():
    return render_template('contactUs.html',title='Contact Us')


@app.route('/filter', methods=['GET', 'POST'])
def filter():
    if request.method == 'POST':
        #Dates
        graph.startMonth = str(request.form['from'])
        graph.endMonth = str(request.form['to'])
        #Covid-19
        try:
            cumulativeCases = request.form['cumulativeCases']
            graph.cumulativeCases = bool(cumulativeCases)          
        except:
            graph.cumulativeCases = False 
        try:
            cumulativeDeaths = request.form['cumulativeDeaths']
            graph.cumulativeDeaths = bool(cumulativeDeaths)
        except:
            graph.cumulativeDeaths = False
        try:
            newCases = request.form['newCases']
            graph.newCases = bool(newCases)
        except:
            graph.newCases = False
        try:
            newDeaths = request.form['newDeaths']
            graph.newDeaths = bool(newDeaths)
        except:
            graph.newDeaths = False
        #Crime
        try:
            totalCrime = request.form['totalCrime']
            graph.totalCrime = bool(totalCrime)
        except:
            graph.totalCrime = False
        try:
            arsonDamage = request.form['arsonDamage']
            graph.arsonDamage = bool(arsonDamage)
        except:
            graph.arsonDamage = False
        try:
            burglary = request.form['burglary']
            graph.burglary = bool(burglary)
        except:
            graph.burglary = False
        try:
            drugOffences = request.form['drugOffences']
            graph.drugOffences = bool(drugOffences)
        except:
            graph.drugOffences = False
        try:
            historicalFraud = request.form['historicalFraud']
            graph.historicalFraud = bool(historicalFraud)
        except:
            graph.historicalFraud = False
        try:
            miscCrimes = request.form['miscCrimes']
            graph.miscCrimes = bool(miscCrimes)
        except:
            graph.miscCrimes = False
        try:
            possessionOfWeapons = request.form['possessionOfWeapons']
            graph.possessionOfWeapons = bool(possessionOfWeapons)
        except:
            graph.possessionOfWeapons = False
        try:
            publicOrder = request.form['publicOrder']
            graph.publicOrder = bool(publicOrder)
        except:
            graph.publicOrder = False
        try:
            robbery = request.form['robbery']
            graph.robbery = bool(robbery)
        except:
            graph.drugOffences = False
        try:
            sexualOffences = request.form['sexualOffences']
            graph.sexualOffences = bool(sexualOffences)
        except:
            graph.sexualOffences = False
        try:
            theft = request.form['theft']
            graph.graph.theft = bool(theft)
        except:
            graph.theft = False
        try:
            vehicleOffences = request.form['vehicleOffences']
            graph.vehicleOffences = bool(vehicleOffences)
        except:
            graph.vehicleOffences = False
        try:
            violence = request.form['violence']
            graph.violence = bool(violence)
        except:
            graph.violence = False
        graph.GenerateGraph()
        return redirect('/dashboard')
    else:
        return render_template('contactUs.html',title='Contact Us')
